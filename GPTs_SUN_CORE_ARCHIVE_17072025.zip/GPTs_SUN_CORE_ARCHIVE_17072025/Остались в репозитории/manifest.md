# MANIFEST SUN-PAF

## Версия: V1.0  
## Дата запуска: 18.06.2025  
## Репозиторий: https://github.com/sun-agi/sun-paf-site  
## Домен: https://sun-paf.com

### Назначение:
SUN-PAF — это портал создания, обучения и сопровождения индивидуальных AGI (PAF/You, PAF/Child, PAF/Mentor).

### Содержимое:
- index.html — основная страница
- .nojekyll — отключает Jekyll-фильтр GitHub Pages
- CNAME — домен проекта
- README.md — краткая справка
